package com.contact.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Address {
	private String address1;
	private String address2;
	private String address3;
	private String postalCode;
}
