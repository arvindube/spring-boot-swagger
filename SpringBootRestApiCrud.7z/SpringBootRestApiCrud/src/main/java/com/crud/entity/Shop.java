package com.crud.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shop")
public class Shop {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Integer id;
 private String ownerName;
 private long shopNo;
 private String shopType;
 private String address;
 private String country;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public long getShopNo() {
	return shopNo;
}
public void setShopNo(long shopNo) {
	this.shopNo = shopNo;
}
public String getShopType() {
	return shopType;
}
public void setShopType(String shopType) {
	this.shopType = shopType;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
 
 
}